var searchData=
[
  ['grupa1_20_28jakaś_20nazwa_20grupy_29_3',['GRUPA1 (Jakaś nazwa grupy)',['../group__test1.html',1,'']]]
];
